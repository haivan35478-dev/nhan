/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo } from 'react';
import { 
  format, 
  addMonths, 
  subMonths, 
  startOfMonth, 
  endOfMonth, 
  startOfWeek, 
  endOfWeek, 
  isSameMonth, 
  isSameDay, 
  addDays, 
  eachDayOfInterval,
  startOfDay,
  endOfDay,
  parseISO,
  isWithinInterval,
  addWeeks,
  subWeeks,
  subDays,
  setHours,
  setMinutes,
  getHours
} from 'date-fns';
import { vi } from 'date-fns/locale';
import { 
  ChevronLeft, 
  ChevronRight, 
  Plus, 
  Calendar as CalendarIcon, 
  Clock, 
  MapPin, 
  Tag, 
  X, 
  MoreVertical, 
  Copy, 
  Trash2, 
  Edit2,
  LayoutGrid,
  Columns,
  Square
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { CalendarEvent, CATEGORIES, Category } from './types';
import { cn } from './lib/utils';

type ViewType = 'day' | 'week' | 'month';

export default function App() {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [view, setView] = useState<ViewType>('month');
  const [events, setEvents] = useState<CalendarEvent[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingEvent, setEditingEvent] = useState<CalendarEvent | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  // Form state
  const [formData, setFormData] = useState<Partial<CalendarEvent>>({
    title: '',
    description: '',
    category: 'Study',
    start_time: format(new Date(), "yyyy-MM-dd'T'HH:mm"),
    end_time: format(addDays(new Date(), 0), "yyyy-MM-dd'T'HH:mm"),
    location: ''
  });

  useEffect(() => {
    fetchEvents();
  }, []);

  const fetchEvents = async () => {
    try {
      const response = await fetch('/api/events');
      const data = await response.json();
      setEvents(data);
    } catch (error) {
      console.error('Failed to fetch events:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSaveEvent = async (e: React.FormEvent) => {
    e.preventDefault();
    const eventToSave = {
      ...formData,
      id: editingEvent?.id || crypto.randomUUID(),
    } as CalendarEvent;

    try {
      const method = editingEvent ? 'PUT' : 'POST';
      const url = editingEvent ? `/api/events/${editingEvent.id}` : '/api/events';
      
      const response = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(eventToSave),
      });

      if (response.ok) {
        fetchEvents();
        setIsModalOpen(false);
        setEditingEvent(null);
        resetForm();
      }
    } catch (error) {
      console.error('Failed to save event:', error);
    }
  };

  const handleDeleteEvent = async (id: string) => {
    if (!confirm('Bạn có chắc chắn muốn xóa lịch này?')) return;
    try {
      const response = await fetch(`/api/events/${id}`, { method: 'DELETE' });
      if (response.ok) {
        fetchEvents();
      }
    } catch (error) {
      console.error('Failed to delete event:', error);
    }
  };

  const handleCopyEvent = (event: CalendarEvent) => {
    const newEvent = { ...event, id: crypto.randomUUID(), title: `${event.title} (Bản sao)` };
    setEditingEvent(null);
    setFormData(newEvent);
    setIsModalOpen(true);
  };

  const resetForm = () => {
    setFormData({
      title: '',
      description: '',
      category: 'Study',
      start_time: format(new Date(), "yyyy-MM-dd'T'HH:mm"),
      end_time: format(addDays(new Date(), 0), "yyyy-MM-dd'T'HH:mm"),
      location: ''
    });
  };

  const openAddModal = (date?: Date) => {
    resetForm();
    if (date) {
      const start = setHours(setMinutes(date, 0), getHours(new Date()));
      setFormData(prev => ({
        ...prev,
        start_time: format(start, "yyyy-MM-dd'T'HH:mm"),
        end_time: format(addWeeks(start, 0), "yyyy-MM-dd'T'HH:mm")
      }));
    }
    setEditingEvent(null);
    setIsModalOpen(true);
  };

  const openEditModal = (event: CalendarEvent) => {
    setEditingEvent(event);
    setFormData(event);
    setIsModalOpen(true);
  };

  const next = () => {
    if (view === 'month') setCurrentDate(addMonths(currentDate, 1));
    else if (view === 'week') setCurrentDate(addWeeks(currentDate, 1));
    else setCurrentDate(addDays(currentDate, 1));
  };

  const prev = () => {
    if (view === 'month') setCurrentDate(subMonths(currentDate, 1));
    else if (view === 'week') setCurrentDate(subWeeks(currentDate, 1));
    else setCurrentDate(subDays(currentDate, 1));
  };

  const filteredEvents = useMemo(() => {
    return events.map(e => ({
      ...e,
      start: parseISO(e.start_time),
      end: parseISO(e.end_time)
    }));
  }, [events]);

  const renderHeader = () => (
    <div className="flex flex-col md:flex-row md:items-center justify-between p-4 bg-white border-b gap-4">
      <div className="flex items-center gap-4">
        <div className="bg-blue-600 text-white p-2 rounded-lg">
          <CalendarIcon size={24} />
        </div>
        <div>
          <h1 className="text-xl font-bold text-gray-900">Lịch DThU</h1>
          <p className="text-sm text-gray-500 capitalize">
            {format(currentDate, 'MMMM yyyy', { locale: vi })}
          </p>
        </div>
      </div>

      <div className="flex items-center bg-gray-100 p-1 rounded-lg self-start md:self-center">
        <button 
          onClick={() => setView('day')}
          className={cn("px-3 py-1.5 rounded-md text-sm font-medium transition-all", view === 'day' ? "bg-white shadow-sm text-blue-600" : "text-gray-600 hover:text-gray-900")}
        >
          Ngày
        </button>
        <button 
          onClick={() => setView('week')}
          className={cn("px-3 py-1.5 rounded-md text-sm font-medium transition-all", view === 'week' ? "bg-white shadow-sm text-blue-600" : "text-gray-600 hover:text-gray-900")}
        >
          Tuần
        </button>
        <button 
          onClick={() => setView('month')}
          className={cn("px-3 py-1.5 rounded-md text-sm font-medium transition-all", view === 'month' ? "bg-white shadow-sm text-blue-600" : "text-gray-600 hover:text-gray-900")}
        >
          Tháng
        </button>
      </div>

      <div className="flex items-center gap-2">
        <button onClick={prev} className="p-2 hover:bg-gray-100 rounded-full transition-colors">
          <ChevronLeft size={20} />
        </button>
        <button 
          onClick={() => setCurrentDate(new Date())}
          className="px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-100 rounded-lg border transition-colors"
        >
          Hôm nay
        </button>
        <button onClick={next} className="p-2 hover:bg-gray-100 rounded-full transition-colors">
          <ChevronRight size={20} />
        </button>
        <button 
          onClick={() => openAddModal()}
          className="ml-2 flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg font-medium shadow-sm transition-all active:scale-95"
        >
          <Plus size={18} />
          <span className="hidden sm:inline">Thêm mới</span>
        </button>
      </div>
    </div>
  );

  const renderMonthView = () => {
    const monthStart = startOfMonth(currentDate);
    const monthEnd = endOfMonth(monthStart);
    const startDate = startOfWeek(monthStart, { weekStartsOn: 1 });
    const endDate = endOfWeek(monthEnd, { weekStartsOn: 1 });

    const calendarDays = eachDayOfInterval({ start: startDate, end: endDate });
    const weekDays = ['T2', 'T3', 'T4', 'T5', 'T6', 'T7', 'CN'];

    return (
      <div className="flex-1 overflow-auto">
        <div className="grid grid-cols-7 border-b bg-gray-50">
          {weekDays.map(day => (
            <div key={day} className="py-2 text-center text-xs font-semibold text-gray-500 uppercase tracking-wider">
              {day}
            </div>
          ))}
        </div>
        <div className="grid grid-cols-7 grid-rows-5 h-full min-h-[600px]">
          {calendarDays.map((day, i) => {
            const dayEvents = filteredEvents.filter(e => isSameDay(e.start, day));
            return (
              <div 
                key={i} 
                onClick={() => openAddModal(day)}
                className={cn(
                  "min-h-[120px] border-r border-b p-2 transition-colors cursor-pointer hover:bg-blue-50/30",
                  !isSameMonth(day, monthStart) && "bg-gray-50 text-gray-400",
                  isSameDay(day, new Date()) && "bg-blue-50/50"
                )}
              >
                <div className="flex justify-between items-start mb-1">
                  <span className={cn(
                    "text-sm font-medium w-7 h-7 flex items-center justify-center rounded-full",
                    isSameDay(day, new Date()) && "bg-blue-600 text-white"
                  )}>
                    {format(day, 'd')}
                  </span>
                </div>
                <div className="space-y-1">
                  {dayEvents.slice(0, 3).map(event => (
                    <div 
                      key={event.id}
                      onClick={(e) => {
                        e.stopPropagation();
                        openEditModal(event);
                      }}
                      className={cn(
                        "text-[10px] sm:text-xs px-1.5 py-0.5 rounded border truncate shadow-sm",
                        CATEGORIES.find(c => c.value === event.category)?.color.replace('bg-', 'bg-opacity-10 text-').replace('500', '700'),
                        CATEGORIES.find(c => c.value === event.category)?.color.replace('bg-', 'border-')
                      )}
                    >
                      {format(event.start, 'HH:mm')} {event.title}
                    </div>
                  ))}
                  {dayEvents.length > 3 && (
                    <div className="text-[10px] text-gray-500 font-medium pl-1">
                      + {dayEvents.length - 3} thêm...
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    );
  };

  const renderWeekView = () => {
    const start = startOfWeek(currentDate, { weekStartsOn: 1 });
    const days = eachDayOfInterval({ start, end: addDays(start, 6) });
    const hours = Array.from({ length: 24 }, (_, i) => i);

    return (
      <div className="flex-1 overflow-auto flex flex-col">
        <div className="grid grid-cols-[60px_1fr] border-b bg-gray-50 sticky top-0 z-10">
          <div className="border-r"></div>
          <div className="grid grid-cols-7">
            {days.map(day => (
              <div key={day.toString()} className="py-3 text-center border-r last:border-r-0">
                <p className="text-xs font-semibold text-gray-500 uppercase">{format(day, 'EEE', { locale: vi })}</p>
                <p className={cn(
                  "text-lg font-bold w-8 h-8 mx-auto flex items-center justify-center rounded-full mt-1",
                  isSameDay(day, new Date()) ? "bg-blue-600 text-white" : "text-gray-900"
                )}>
                  {format(day, 'd')}
                </p>
              </div>
            ))}
          </div>
        </div>
        <div className="flex-1 grid grid-cols-[60px_1fr] relative">
          <div className="border-r bg-gray-50">
            {hours.map(hour => (
              <div key={hour} className="h-20 text-[10px] text-gray-400 text-right pr-2 pt-2 border-b border-gray-100">
                {hour}:00
              </div>
            ))}
          </div>
          <div className="grid grid-cols-7 relative">
            {days.map(day => (
              <div key={day.toString()} className="relative border-r last:border-r-0 h-full group">
                {hours.map(hour => (
                  <div 
                    key={hour} 
                    onClick={() => {
                      const d = setHours(day, hour);
                      openAddModal(d);
                    }}
                    className="h-20 border-b border-gray-100 hover:bg-blue-50/20 cursor-pointer transition-colors"
                  />
                ))}
                {filteredEvents
                  .filter(e => isSameDay(e.start, day))
                  .map(event => {
                    const startHour = getHours(event.start);
                    const startMinutes = event.start.getMinutes();
                    const durationInMin = (event.end.getTime() - event.start.getTime()) / (1000 * 60);
                    const top = (startHour * 80) + (startMinutes * 80 / 60);
                    const height = (durationInMin * 80 / 60);

                    return (
                      <div
                        key={event.id}
                        onClick={() => openEditModal(event)}
                        style={{ top, height: Math.max(height, 20) }}
                        className={cn(
                          "absolute left-1 right-1 rounded p-1 text-[10px] overflow-hidden border shadow-sm cursor-pointer z-10 hover:brightness-95 transition-all",
                          CATEGORIES.find(c => c.value === event.category)?.color.replace('bg-', 'bg-opacity-20 text-').replace('500', '800'),
                          CATEGORIES.find(c => c.value === event.category)?.color.replace('bg-', 'border-')
                        )}
                      >
                        <p className="font-bold truncate">{event.title}</p>
                        <p className="opacity-70">{format(event.start, 'HH:mm')} - {format(event.end, 'HH:mm')}</p>
                      </div>
                    );
                  })}
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  };

  const renderDayView = () => {
    const hours = Array.from({ length: 24 }, (_, i) => i);
    const dayEvents = filteredEvents.filter(e => isSameDay(e.start, currentDate));

    return (
      <div className="flex-1 overflow-auto flex flex-col bg-white">
        <div className="p-4 border-b bg-gray-50 sticky top-0 z-10">
          <h2 className="text-lg font-bold text-gray-900">{format(currentDate, 'EEEE, d MMMM', { locale: vi })}</h2>
        </div>
        <div className="flex-1 grid grid-cols-[80px_1fr] relative">
          <div className="border-r bg-gray-50">
            {hours.map(hour => (
              <div key={hour} className="h-24 text-xs text-gray-400 text-right pr-4 pt-2 border-b border-gray-100">
                {hour}:00
              </div>
            ))}
          </div>
          <div className="relative h-full">
            {hours.map(hour => (
              <div 
                key={hour} 
                onClick={() => openAddModal(setHours(currentDate, hour))}
                className="h-24 border-b border-gray-100 hover:bg-blue-50/20 cursor-pointer transition-colors"
              />
            ))}
            {dayEvents.map(event => {
              const startHour = getHours(event.start);
              const startMinutes = event.start.getMinutes();
              const durationInMin = (event.end.getTime() - event.start.getTime()) / (1000 * 60);
              const top = (startHour * 96) + (startMinutes * 96 / 60);
              const height = (durationInMin * 96 / 60);

              return (
                <div
                  key={event.id}
                  onClick={() => openEditModal(event)}
                  style={{ top, height: Math.max(height, 30) }}
                  className={cn(
                    "absolute left-4 right-4 rounded-lg p-3 text-xs overflow-hidden border shadow-md cursor-pointer z-10 hover:brightness-95 transition-all",
                    CATEGORIES.find(c => c.value === event.category)?.color.replace('bg-', 'bg-opacity-20 text-').replace('500', '800'),
                    CATEGORIES.find(c => c.value === event.category)?.color.replace('bg-', 'border-')
                  )}
                >
                  <div className="flex justify-between items-start">
                    <div>
                      <p className="font-bold text-sm">{event.title}</p>
                      <p className="opacity-70 flex items-center gap-1 mt-1">
                        <Clock size={12} />
                        {format(event.start, 'HH:mm')} - {format(event.end, 'HH:mm')}
                      </p>
                      {event.location && (
                        <p className="opacity-70 flex items-center gap-1 mt-1">
                          <MapPin size={12} />
                          {event.location}
                        </p>
                      )}
                    </div>
                    <div className="flex gap-2">
                      <button 
                        onClick={(e) => { e.stopPropagation(); handleCopyEvent(event); }}
                        className="p-1 hover:bg-black/5 rounded"
                      >
                        <Copy size={14} />
                      </button>
                      <button 
                        onClick={(e) => { e.stopPropagation(); handleDeleteEvent(event.id); }}
                        className="p-1 hover:bg-black/5 rounded text-red-600"
                      >
                        <Trash2 size={14} />
                      </button>
                    </div>
                  </div>
                  {event.description && <p className="mt-2 text-[11px] line-clamp-2 opacity-80">{event.description}</p>}
                </div>
              );
            })}
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="flex flex-col h-screen bg-gray-50 font-sans">
      {renderHeader()}
      
      <main className="flex-1 flex flex-col overflow-hidden">
        {isLoading ? (
          <div className="flex-1 flex items-center justify-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
          </div>
        ) : (
          <>
            {view === 'month' && renderMonthView()}
            {view === 'week' && renderWeekView()}
            {view === 'day' && renderDayView()}
          </>
        )}
      </main>

      {/* Event Modal */}
      <AnimatePresence>
        {isModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm">
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="bg-white rounded-2xl shadow-2xl w-full max-w-md overflow-hidden"
            >
              <div className="flex items-center justify-between p-4 border-b bg-gray-50">
                <h3 className="text-lg font-bold text-gray-900">
                  {editingEvent ? 'Chỉnh sửa lịch' : 'Thêm lịch mới'}
                </h3>
                <button onClick={() => setIsModalOpen(false)} className="p-2 hover:bg-gray-200 rounded-full transition-colors">
                  <X size={20} />
                </button>
              </div>

              <form onSubmit={handleSaveEvent} className="p-6 space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-gray-500 uppercase mb-1">Tiêu đề</label>
                  <input 
                    required
                    type="text" 
                    value={formData.title}
                    onChange={e => setFormData({...formData, title: e.target.value})}
                    placeholder="Nhập tiêu đề sự kiện..."
                    className="w-full px-4 py-2 rounded-lg border focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-gray-500 uppercase mb-1">Bắt đầu</label>
                    <input 
                      required
                      type="datetime-local" 
                      value={formData.start_time}
                      onChange={e => setFormData({...formData, start_time: e.target.value})}
                      className="w-full px-4 py-2 rounded-lg border focus:ring-2 focus:ring-blue-500 outline-none transition-all"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-gray-500 uppercase mb-1">Kết thúc</label>
                    <input 
                      required
                      type="datetime-local" 
                      value={formData.end_time}
                      onChange={e => setFormData({...formData, end_time: e.target.value})}
                      className="w-full px-4 py-2 rounded-lg border focus:ring-2 focus:ring-blue-500 outline-none transition-all"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-gray-500 uppercase mb-1">Danh mục</label>
                  <div className="grid grid-cols-3 gap-2">
                    {CATEGORIES.map(cat => (
                      <button
                        key={cat.value}
                        type="button"
                        onClick={() => setFormData({...formData, category: cat.value})}
                        className={cn(
                          "px-3 py-2 rounded-lg text-xs font-medium border transition-all flex items-center justify-center gap-1",
                          formData.category === cat.value 
                            ? `${cat.color} text-white border-transparent shadow-md` 
                            : "bg-white text-gray-600 hover:bg-gray-50"
                        )}
                      >
                        <Tag size={12} />
                        {cat.label}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-gray-500 uppercase mb-1">Địa điểm</label>
                  <div className="relative">
                    <MapPin className="absolute left-3 top-2.5 text-gray-400" size={18} />
                    <input 
                      type="text" 
                      value={formData.location}
                      onChange={e => setFormData({...formData, location: e.target.value})}
                      placeholder="Phòng học, sân vận động..."
                      className="w-full pl-10 pr-4 py-2 rounded-lg border focus:ring-2 focus:ring-blue-500 outline-none transition-all"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-gray-500 uppercase mb-1">Ghi chú</label>
                  <textarea 
                    value={formData.description}
                    onChange={e => setFormData({...formData, description: e.target.value})}
                    placeholder="Thêm chi tiết..."
                    rows={3}
                    className="w-full px-4 py-2 rounded-lg border focus:ring-2 focus:ring-blue-500 outline-none transition-all resize-none"
                  />
                </div>

                <div className="flex gap-3 pt-4">
                  {editingEvent && (
                    <button 
                      type="button"
                      onClick={() => handleDeleteEvent(editingEvent.id)}
                      className="flex-1 px-4 py-2.5 rounded-xl border border-red-200 text-red-600 font-semibold hover:bg-red-50 transition-all active:scale-95"
                    >
                      Xóa
                    </button>
                  )}
                  <button 
                    type="submit"
                    className="flex-[2] bg-blue-600 text-white px-4 py-2.5 rounded-xl font-semibold hover:bg-blue-700 shadow-lg shadow-blue-200 transition-all active:scale-95"
                  >
                    {editingEvent ? 'Cập nhật' : 'Lưu lịch'}
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Mobile Floating Action Button */}
      <button 
        onClick={() => openAddModal()}
        className="fixed bottom-6 right-6 w-14 h-14 bg-blue-600 text-white rounded-full shadow-xl flex items-center justify-center sm:hidden active:scale-90 transition-transform z-40"
      >
        <Plus size={28} />
      </button>
    </div>
  );
}
