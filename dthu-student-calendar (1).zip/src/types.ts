export type Category = 'Study' | 'Exam' | 'Entertainment' | 'Sports' | 'Other';

export interface CalendarEvent {
  id: string;
  title: string;
  description?: string;
  start_time: string; // ISO string
  end_time: string;   // ISO string
  category: Category;
  location?: string;
}

export const CATEGORIES: { label: string; value: Category; color: string }[] = [
  { label: 'Lịch học', value: 'Study', color: 'bg-blue-500' },
  { label: 'Lịch thi', value: 'Exam', color: 'bg-red-500' },
  { label: 'Giải trí', value: 'Entertainment', color: 'bg-green-500' },
  { label: 'Thể thao', value: 'Sports', color: 'bg-orange-500' },
  { label: 'Khác', value: 'Other', color: 'bg-gray-500' },
];
