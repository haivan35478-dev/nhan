import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import Database from "better-sqlite3";

const db = new Database("calendar.db");

// Initialize database
db.exec(`
  CREATE TABLE IF NOT EXISTS events (
    id TEXT PRIMARY KEY,
    title TEXT NOT NULL,
    description TEXT,
    start_time TEXT NOT NULL,
    end_time TEXT NOT NULL,
    category TEXT NOT NULL,
    location TEXT
  )
`);

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API Routes
  app.get("/api/events", (req, res) => {
    try {
      const events = db.prepare("SELECT * FROM events").all();
      res.json(events);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch events" });
    }
  });

  app.post("/api/events", (req, res) => {
    const { id, title, description, start_time, end_time, category, location } = req.body;
    try {
      db.prepare(`
        INSERT INTO events (id, title, description, start_time, end_time, category, location)
        VALUES (?, ?, ?, ?, ?, ?, ?)
      `).run(id, title, description, start_time, end_time, category, location);
      res.status(201).json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to create event" });
    }
  });

  app.put("/api/events/:id", (req, res) => {
    const { id } = req.params;
    const { title, description, start_time, end_time, category, location } = req.body;
    try {
      db.prepare(`
        UPDATE events 
        SET title = ?, description = ?, start_time = ?, end_time = ?, category = ?, location = ?
        WHERE id = ?
      `).run(title, description, start_time, end_time, category, location, id);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to update event" });
    }
  });

  app.delete("/api/events/:id", (req, res) => {
    const { id } = req.params;
    try {
      db.prepare("DELETE FROM events WHERE id = ?").run(id);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to delete event" });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
